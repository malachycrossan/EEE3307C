#let coverpage(title: str, author, class, due_date: datetime, last_modified: datetime) = [
  #align(center, [
  #v(6em)
  #text(14pt, weight: "bold", title)
  #v(2em)
  #text(12pt, style: "italic", author.join(" & "))
  #v(1em)
  #text(style: "italic", class)
  #v(1em)
  #grid(
    columns: 2,
    gutter: 8pt,
    "Due Date:", due_date.display(),
    "Last modified:", last_modified.display(),
  )
])
#pagebreak()
]

#set text(font: "Liberation Serif", size: 10pt)
#set par(justify: false)
#show raw.where(lang: "python"): it => rect(text(size: 6pt,it), width: 100%, radius: .5em, inset: 1em,)
#show math.equation.where(block: true):  it => rect(it,radius: 1em, inset: 1em, fill: silver)
#set math.equation(numbering: "Eq 1")
#set figure(kind: image)
#set heading(numbering: "1.A.1.a")
#let mathHeading(content) = text(
  size: 15pt,
  fill: blue.darken(40%),
  content,
)

//#set page(height: auto)

// Footer with "Page X of Y"
#show: page.with(
  footer: align(center)[#context[
    Page #counter(page).display() of #counter(page).final().first()
  ]],
)

#let author = (
  "Malachy Crossan",
  "Brandon Saavedra",
  )
#let class = "EEE3307-C0013: Electronics I"
#let title = "Experiment 5: Transistor Small-Signal Amplifiers"
#let description = ""
#set document(author: author, title: title, description: description)

#coverpage(
  title: title,
  author,
  class,
  due_date: datetime(year: 2026, month: 11, day: 10),
  last_modified: datetime.today(),
)

#counter(heading).update(5)

== Objective
The goal of this experiment is to study small-signal transistor amplifiers built around the 2N2222 BJT. A common-emitter (CE) amplifier with and without an emitter bypass capacitor and a common-collector (emitter follower) amplifier are designed, simulated, and built. For each circuit the Q-point, maximum unclipped output, small-signal voltage gains $A_"vi" = v_o/v_i$ and $A_"vs" = v_o/v_s$, and the input and output resistances are calculated, then compared against simulation and laboratory measurements.

*Lab partners:* Malachy Crossan & Brandon Saavedra \
*Data taken:* November 3, 2026, approximately 2:45 PM

== Pre-Lab
Given values: $V_"CC" = 12V$, $R_C = 6.2k Omega$, $R_E = 1.8k Omega$, $R_L = 2.2k Omega$, $R_S = 1.8k Omega$, $C_E = 100 mu F$, $C_B = C_L = 10 mu F$. For the 2N2222 the lab manual gives $beta approx 150$ and $V_A approx 100V$. Throughout, $V_"BE" = 0.7V$, $V_T = k T\/q approx 26m V$ and $V_"CE(sat)" approx 0.2V$ are assumed.

=== Common-Emitter Amplifier
#figure(
  image("images/fig1_ce.png", width: 70%),
  caption: [Common-emitter amplifier (Fig. 1 of the lab manual)],
) <fig:ce>

// fig1 with values from LTSPICE
// VCC = 12 V,
//  RC = 6.2 kΩ,
//  RE = 1.8 kΩ,
//  RL = 2.2 kΩ,
//  RS = 1.8 kΩ,
//  CE = 100 μF.
//  CL = 10uF
//  CB = 10uF
==== Calculate $R_1$ and $R_2$
Targeting $I_"CQ" approx 1m A$
$
  R_"TH" &= .1 times (1+beta) times R_E \
  &= .1 times 151 times 1.8k Omega approx 27.2k Omega \
$

$
  I_B = (1m A)/150 = 6.67mu A \
  I_E = I_B times (1+ beta) = 1.007m A \
$
  
$
  V_"TH" &= V_"BE" + I_E times R_E + I_B times R_"TH" \
  &= .7 + 1.81 + .18 = 2.69V
$

$
  V_"TH" = V_"CC" times R_2/(R_1+ R_2) \
  R_1 = 121.249k Omega approx 120k Omega \
  R_2 = 35.033k Omega approx 36k Omega \
$

==== Compute Q-point and max unclipped output voltage
With the standard values $R_1 = 120k Omega$ and $R_2 = 36k Omega$ the Thévenin equivalent of the base divider is recomputed:
$
  R_"TH" &= R_1 || R_2 = 120k Omega || 36k Omega = 27.69k Omega \
  V_"TH" &= 12 times (36k)/(120k + 36k) = 2.769V
$

$
  I_"BQ" &= (V_"TH" - V_"BE")/(R_"TH" + (1+beta) R_E) = (2.769 - .7)/(27.69k + 151 times 1.8k) = 6.91 mu A \
  I_"CQ" &= beta I_"BQ" = 1.036m A, quad I_"EQ" = (1+beta) I_"BQ" = 1.043m A
$

$
  V_"CEQ" &= V_"CC" - I_"CQ" R_C - I_"EQ" R_E \
  &= 12 - 1.036m times 6.2k - 1.043m times 1.8k = 3.70V
$

The Q-point is therefore $(I_"CQ", V_"CEQ") = (1.04m A, 3.70V)$. With $C_E$ shorting $R_E$ at signal frequency, the AC load line has slope $-1\/R_"ac"$ where
$
  R_"ac" = R_C || R_L = 6.2k || 2.2k = 1.624k Omega
$
The output can swing down until the transistor saturates or up until it cuts off:
$
  "Saturation limit:" & quad V_"CEQ" - V_"CE(sat)" = 3.70 - 0.2 = 3.50V \
  "Cutoff limit:" & quad I_"CQ" R_"ac" = 1.036m times 1.624k = 1.68V
$
The cutoff limit is smaller, so the *maximum unclipped output is $approx 1.68V$ peak ($3.37V_"pp"$)*.

==== Compute the small-signal voltage gain $A_"vi" = v_o/v_i$ and $A_"vs" = v_o/v_s$
$
  g_m &= I_"CQ"/V_T = (1.036m)/(26m) = 39.86 m A\/V \
  r_pi &= beta/g_m = 150/(39.86m) = 3.763k Omega \
  r_o &= V_A/I_"CQ" = 100/(1.036m) = 96.5k Omega
$

$
  A_"vi" &= -g_m (r_o || R_C || R_L) = -39.86m times 1.597k = -63.7 \
  A_"vs" &= A_"vi" times R_i/(R_i + R_S) = -63.7 times (3.313k)/(3.313k + 1.8k) = -41.2
$

==== Compute the input and output resistances
$
  R_i &= R_1 || R_2 || r_pi = 27.69k || 3.763k = 3.31k Omega \
  R_o &= R_C || r_o = 6.2k || 96.5k = 5.83k Omega
$

=== Common-Emitter Amplifier without $C_E$
==== Compute Q-point and max unclipped output voltage
$C_E$ is an open circuit at DC, so removing it does not change the bias: the Q-point is still $(I_"CQ", V_"CEQ") = (1.04m A, 3.70V)$.

Without the bypass, $R_E$ is in the AC collector-emitter loop. The collector current swing $i_c$ produces $v_"ce" = i_c (R_C || R_L + R_E)$ while only the part across $R_C || R_L$ appears at the output:
$
  R_"ac" = R_C || R_L + R_E = 1.624k + 1.8k = 3.424k Omega
$
$
  "Saturation:" & quad i_"c,max" = (V_"CEQ" - V_"CE(sat)")/R_"ac" = (3.70 - 0.2)/(3.424k) = 1.021m A arrow v_o = 1.021m times 1.624k = 1.66V \
  "Cutoff:" & quad i_"c,max" = I_"CQ" = 1.036m A arrow v_o = 1.036m times 1.624k = 1.68V
$
The two limits are almost equal; saturation is reached first, so the *maximum unclipped output is $approx 1.66V$ peak ($3.32V_"pp"$)*.

==== Compute the small-signal voltage gain Avi = vo/vi and Avs = vo/vs
The resistance looking into the base now includes the reflected emitter resistor:
$
  R_"ib" = r_pi + (1+beta) R_E = 3.763k + 151 times 1.8k = 275.6k Omega
$
$
  A_"vi" &= (-beta (R_C || R_L))/(r_pi + (1+beta) R_E) = (-150 times 1.624k)/(275.6k) = -0.884 \
  A_"vs" &= A_"vi" times R_i/(R_i + R_S) = -0.884 times (25.16k)/(25.16k + 1.8k) = -0.825
$

==== Compute the input and output resistances
$
  R_i &= R_1 || R_2 || [r_pi + (1+beta) R_E] = 27.69k || 275.6k = 25.2k Omega \
  R_o &approx R_C = 6.2k Omega
$
($r_o$ is neglected here: with emitter degeneration the resistance looking into the collector is roughly $r_o (1 + g_m R_E)$, which is far larger than $R_C$.)

Removing $C_E$ trades almost all of the gain for a much higher and more predictable input resistance: the gain now depends only on the resistor ratio $approx R_C||R_L\/R_E$ instead of on $g_m$.

=== Common-Collector (Emitter Follower) Amplifier
#figure(
  image("images/fig2_ef.png", width: 70%),
  caption: [Emitter follower (Fig. 2 of the lab manual)],
) <fig:ef>

==== Calculate $R_1$ and $R_2$
The bias network is designed with the same rule as the CE amplifier. Since $R_C$ does not appear in the base-emitter loop, the base equations are identical:
$
  R_"TH" &= .1 times (1+beta) times R_E = .1 times 151 times 1.8k Omega approx 27.2k Omega \
  V_"TH" &= V_"BE" + I_E times R_E + I_B times R_"TH" = .7 + 1.81 + .18 = 2.69V
$
$
  R_1 = R_"TH" times V_"CC"/V_"TH" = 121.2k Omega approx 120k Omega \
  R_2 = R_"TH" times V_"CC"/(V_"CC" - V_"TH") = 35.0k Omega approx 36k Omega
$
The same $R_1 = 120k Omega$ and $R_2 = 36k Omega$ were therefore used for both circuits.

==== Compute Q-point and max unclipped output voltage
$
  I_"BQ" = 6.91 mu A, quad I_"CQ" = 1.036m A, quad I_"EQ" = 1.043m A \
  V_E = I_"EQ" R_E = 1.043m times 1.8k = 1.88V \
  V_"CEQ" = V_"CC" - I_"EQ" R_E = 12 - 1.88 = 10.12V
$
The Q-point is $(I_"CQ", V_"CEQ") = (1.04m A, 10.1V)$. The AC load on the emitter is $R_"ac" = R_E || R_L = 1.8k || 2.2k = 990 Omega$:
$
  "Saturation limit:" & quad V_"CEQ" - V_"CE(sat)" = 10.12 - 0.2 = 9.92V \
  "Cutoff limit:" & quad I_"EQ" R_"ac" = 1.043m times 990 = 1.03V
$
The *maximum unclipped output is $approx 1.03V$ peak ($2.07V_"pp"$)*, limited by cutoff on the negative half-cycle.

==== Compute the small-signal voltage gain Avi = vo/vi and Avs = vo/vs
The effective emitter load is $R'_E = R_E || R_L || r_o = 1.8k || 2.2k || 96.5k = 980 Omega$.
$
  A_"vi" &= ((1+beta) R'_E)/(r_pi + (1+beta) R'_E) = (151 times 980)/(3.763k + 151 times 980) = (147.97k)/(151.73k) = 0.975 \
  A_"vs" &= A_"vi" times R_i/(R_i + R_S) = 0.975 times (23.42k)/(23.42k + 1.8k) = 0.906
$

==== Compute the input and output resistances
$
  R_i &= R_1 || R_2 || [r_pi + (1+beta) R'_E] = 27.69k || 151.7k = 23.4k Omega \
  R_o &= (r_pi + R_1 || R_2 || R_S)/(1+beta) || R_E || r_o \
  &= (3.763k + 1.690k)/151 || 1.8k || 96.5k = 36.1 || 1.8k || 96.5k = 35.4 Omega
$

#figure(
  table(
    columns: 4,
    align: center + horizon,
    table.header([*Parameter*], [*CE with $C_E$*], [*CE without $C_E$*], [*Emitter follower*]),
    [$I_"CQ"$], [1.036 mA], [1.036 mA], [1.036 mA],
    [$V_"CEQ"$], [3.70 V], [3.70 V], [10.12 V],
    [Max unclipped $v_o$], [1.68 V#sub[pk] (cutoff)], [1.66 V#sub[pk] (saturation)], [1.03 V#sub[pk] (cutoff)],
    [$A_"vi"$], [$-63.7$], [$-0.884$], [$0.975$],
    [$A_"vs"$], [$-41.2$], [$-0.825$], [$0.906$],
    [$R_i$], [3.31 kΩ], [25.2 kΩ], [23.4 kΩ],
    [$R_o$], [5.83 kΩ], [≈ 6.2 kΩ], [35.4 Ω],
  ),
  caption: [Summary of pre-lab calculations],
) <tab:prelab>

== Simulation
All three circuits were simulated in SPICE (ngspice) with the component values above. The transistor uses the standard 2N2222 library model with the forward current gain set to $beta_F = 150$ (as in Experiment 3) and $V_"AF" = 100V$, so it matches the hand-calculation assumptions. Each circuit was driven by a 5 kHz sine of $7.0m V_"rms"$ ($9.9m V$ peak), the same source amplitude used in lab. The DC operating point gives the Q-point, and a 6 ms transient gives the RMS values of $v_s$, $v_i$, $v_o$ and the source current $i_s$ over the last ten cycles. The gains and resistances are then found exactly as in the lab procedure:
$
  A_"vs" = v_o/v_s, quad A_"vi" = v_o/v_i, quad R_i = v_i/i_s, quad R_o = R_L times (v_"o,open" - v_L)/v_L
$
where $v_"o,open"$ is the output with $R_L$ removed.

=== Common-Emitter Amplifier
#figure(
  image("images/sim_ce.png", width: 85%),
  caption: [Simulated CE amplifier waveforms. $v_o$ (right axis) is inverted relative to $v_s$ and $v_i$.],
) <fig:simce>

The simulated operating point is $I_"CQ" = 1.062m A$, $V_"CEQ" = 3.50V$. With $v_s = 7.0m V_"rms"$ the simulation gives $v_i = 4.55m V_"rms"$ and $v_o = 292m V_"rms"$, so $A_"vs" = -41.7$ and $A_"vi" = -64.1$. The input resistance is $R_i = 3.35k Omega$; removing $R_L$ raises the output to $1.065V_"rms"$, giving $R_o = 5.82k Omega$.

=== Common-Emitter Amplifier without $C_E$
#figure(
  image("images/sim_cenoce.png", width: 85%),
  caption: [Simulated CE amplifier waveforms with $C_E$ removed],
) <fig:simcenoce>

The bias is unchanged ($I_"CQ" = 1.062m A$, $V_"CEQ" = 3.50V$). The gain collapses to $A_"vs" = -0.825$ and $A_"vi" = -0.884$ ($v_o = 5.77m V_"rms"$), while the input resistance rises to $R_i = 25.1k Omega$. The output resistance is $R_o = 6.19k Omega approx R_C$.

=== Common-Collector (Emitter Follower) Amplifier
#figure(
  image("images/sim_ef.png", width: 85%),
  caption: [Simulated emitter follower waveforms. $v_o$ follows $v_i$ in phase with slightly less amplitude.],
) <fig:simef>

The simulated operating point is $I_"CQ" = 1.068m A$, $V_"CEQ" = 10.07V$. The follower gives $A_"vs" = 0.907$, $A_"vi" = 0.976$, $R_i = 23.7k Omega$ and $R_o = 34.1 Omega$.

=== Maximum Unclipped Output
To check the load-line limits, each circuit was driven past its predicted clipping point (@fig:simclip). The CE amplifier with $C_E$ flattens on the positive half-cycle near $+1.6V$ (cutoff). Its negative half-cycle is visibly stretched long before it clips, because with $v_"be"$ swinging tens of millivolts the exponential $i_C$–$v_"BE"$ curve makes the bypassed stage strongly non-linear. Without $C_E$ the output clips at $+1.69V$ (cutoff) and $-1.63V$ (saturation), close to the predicted $1.68V$ and $1.66V$. The emitter follower clips only on the negative side at $-1.10V$, where the transistor cuts off, compared with $1.03V$ predicted.

#figure(
  image("images/sim_clip.png", width: 100%),
  caption: [Simulated outputs driven past the maximum unclipped level],
) <fig:simclip>

#figure(
  table(
    columns: 7,
    align: center + horizon,
    table.header(
      table.cell(rowspan: 2)[*Parameter*],
      table.cell(colspan: 2)[*CE with $C_E$*],
      table.cell(colspan: 2)[*CE without $C_E$*],
      table.cell(colspan: 2)[*Emitter follower*],
      [Calc.], [Sim.], [Calc.], [Sim.], [Calc.], [Sim.],
    ),
    [$I_"CQ"$ (mA)], [1.036], [1.062], [1.036], [1.062], [1.036], [1.068],
    [$V_"CEQ"$ (V)], [3.70], [3.50], [3.70], [3.50], [10.12], [10.07],
    [$A_"vs"$], [$-41.2$], [$-41.7$], [$-0.825$], [$-0.825$], [0.906], [0.907],
    [$A_"vi"$], [$-63.7$], [$-64.1$], [$-0.884$], [$-0.884$], [0.975], [0.976],
    [$R_i$], [3.31 kΩ], [3.35 kΩ], [25.2 kΩ], [25.1 kΩ], [23.4 kΩ], [23.7 kΩ],
    [$R_o$], [5.83 kΩ], [5.82 kΩ], [6.2 kΩ], [6.19 kΩ], [35.4 Ω], [34.1 Ω],
  ),
  caption: [Pre-lab calculations compared with simulation],
) <tab:sim>

The simulated gains and resistances agree with the hand calculations to within 4%, and the Q-point to within about 5%. The small difference in Q-point comes from the SPICE model's $V_"BE" approx 0.65V$ at 1 mA (slightly below the assumed 0.7 V) and, for the emitter follower, from the Early effect at the larger $V_"CE"$.

== Experimental Procedure
The circuits of @fig:ce and @fig:ef were built on a breadboard with $R_1 = 120k Omega$, $R_2 = 36k Omega$, $C_B = C_L = 10 mu F$ and $C_E = 100 mu F$ (polarity observed), powered from a 12 V supply. The function generator was set to a 5 kHz sine of $7.0m V_"rms"$. RMS voltages were read with the bench multimeter, and the waveforms were viewed on the oscilloscope with 10:1 probes.

For each amplifier:
+ The DC Q-point was measured.
+ $v_s$, $v_i$ and $v_o$ (with $R_L$ connected) were measured to find $A_"vs"$ and $A_"vi"$.
+ The voltage across $R_S$ was measured and divided by $R_S$ to obtain $i_s$. A direct current measurement with the meter (0.0004 mA) was attempted, but at about 1 µA the signal current was below the meter's useful resolution, so it was not used. The input resistance was then found as $R_i = v_i\/i_s$. (The lab manual's expression $(v_s - v_i)\/i_s$ is the voltage across $R_S$ divided by the current through it, which simply returns $R_S$, so $v_i\/i_s$ is used.)
+ The output was measured with $R_L$ connected ($v_L$) and disconnected ($v_o$), and $R_o = R_L (v_o - v_L)\/v_L$ was computed.

The lab procedure measures the CE amplifier only with $C_E$ in place; the unbypassed configuration was studied in the pre-lab and simulation only.

=== Common-Emitter Amplifier
*Q-point:* $I_"CQ" = 1.11m A$, $V_"CEQ" = 2.37V$.

*Gains:* $v_s = 7.0m V_"rms"$, $v_i = 5.0m V_"rms"$, $v_o = 308m V_"rms"$
$
  A_"vs" = -(308m)/(7.0m) = -44.0, quad A_"vi" = -(308m)/(5.0m) = -61.6
$
The negative sign comes from the oscilloscope captures (@fig:pro01, @fig:pro02), where the output is 180° out of phase with the input.

*Input resistance:* $V_(R_S) = 2.3m V_"rms"$
$
  i_s = (2.3m V)/(1.8k Omega) = 1.28 mu A, quad R_i = v_i/i_s = (5.0m V)/(1.28 mu A) = 3.91k Omega
$

*Output resistance:* $v_L = 308m V_"rms"$ (with $R_L$), $v_o = 960m V_"rms"$ (without $R_L$)
$
  R_o = R_L times (v_o - v_L)/v_L = 2.2k times (960 - 308)/308 = 4.66k Omega
$

#figure(
  image("images/PRO01.png", width: 90%),
  caption: [CE amplifier, $v_s$ (CH2, green, 20 mV/div) and $v_o$ (CH1, yellow, 200 mV/div) at 5 kHz],
) <fig:pro01>

#figure(
  image("images/PRO02.png", width: 90%),
  caption: [CE amplifier, $v_i$ (CH2, green, 20 mV/div) and $v_o$ (CH1, yellow, 200 mV/div) at 5 kHz],
) <fig:pro02>

On the oscilloscope the output is a clean, undistorted, inverted sine of about $0.93$–$0.96V_"pp"$. The input channel is dominated by noise spikes from the 10:1 probe at 20 mV/div: the scope reports about $73m V_"pp"$ for both $v_s$ and $v_i$, while the underlying sinusoid is only about $20m V_"pp"$. That is why the RMS multimeter readings were used for every calculation instead of the scope's peak-to-peak values. (A $308m V_"rms"$ output corresponds to $871m V_"pp"$; the scope's slightly higher reading is again noise on the trace.)

=== Common-Collector (Emitter Follower) Amplifier
*Gains:* $v_s = 7.0m V_"rms"$, $v_i = 6.6m V_"rms"$, $v_o = 6.4m V_"rms"$
$
  A_"vs" = (6.4m)/(7.0m) = 0.914, quad A_"vi" = (6.4m)/(6.6m) = 0.970
$

*Input resistance:* $V_(R_S) = 1.3m V_"rms"$
$
  i_s = (1.3m V)/(1.8k Omega) = 0.722 mu A, quad R_i = v_i/i_s = (6.6m V)/(0.722 mu A) = 9.14k Omega
$

*Output resistance:* $v_L = 6.4m V_"rms"$ (with $R_L$), $v_o = 6.5m V_"rms"$ (without $R_L$)
$
  R_o = R_L times (v_o - v_L)/v_L = 2.2k times (6.5 - 6.4)/6.4 = 34.4 Omega
$

== Results and Discussion
#figure(
  table(
    columns: 5,
    align: center + horizon,
    table.header([*Parameter*], [*Calculated*], [*Simulated*], [*Measured*], [*Error vs. calc.*]),
    table.cell(colspan: 5, align: left)[_Common-emitter amplifier with $C_E$_],
    [$I_"CQ"$], [1.036 mA], [1.062 mA], [1.11 mA], [+7.1%],
    [$V_"CEQ"$], [3.70 V], [3.50 V], [2.37 V], [−35.9%],
    [$A_"vs"$], [$-41.2$], [$-41.7$], [$-44.0$], [+6.7%],
    [$A_"vi"$], [$-63.7$], [$-64.1$], [$-61.6$], [−3.2%],
    [$R_i$], [3.31 kΩ], [3.35 kΩ], [3.91 kΩ], [+18.1%],
    [$R_o$], [5.83 kΩ], [5.82 kΩ], [4.66 kΩ], [−20.1%],
    table.cell(colspan: 5, align: left)[_Emitter follower_],
    [$A_"vs"$], [0.906], [0.907], [0.914], [+1.0%],
    [$A_"vi"$], [0.975], [0.976], [0.970], [−0.6%],
    [$R_i$], [23.4 kΩ], [23.7 kΩ], [9.14 kΩ], [−61.0%],
    [$R_o$], [35.4 Ω], [34.1 Ω], [34.4 Ω], [−2.9%],
  ),
  caption: [Calculated, simulated and measured results],
) <tab:results>

=== Common-Emitter Amplifier
*Q-point.* The measured collector current of 1.11 mA is 7% above the 1.04 mA design value, which is well within what is expected from a real 2N2222. Its $beta$ is usually higher than the 150 assumed, and its $V_"BE"$ is usually a little below 0.7 V; both raise $I_C$ with this bias network. The larger current accounts for about 0.6 V of the drop in $V_"CEQ"$. The remainder (3.70 V predicted, 2.37 V measured) is attributed to resistor tolerances on $R_C$ and $R_E$ (5% on 6.2 kΩ alone is ±0.35 V at 1.1 mA). The transistor was still well inside the active region. The lower $V_"CEQ"$ reduces the saturation headroom to about 2.2 V, but the loaded output is still cutoff-limited at about $1.11m times 1.624k approx 1.8V$ peak, so the 0.44 V peak output measured was far from clipping.

*Gains.* $A_"vi"$ was 3.2% below the predicted value and $A_"vs"$ was 6.7% above it. These deviations go in opposite directions because of the input resistance: the measured $v_i\/v_s = 0.71$ is larger than the predicted 0.65, so less signal was lost across $R_S$ than expected. Both gains, and the 180° phase inversion, confirm the expected CE behavior. The simulated output of $292m V_"rms"$ for the same 7 mV source is within 6% of the measured $308m V_"rms"$.

*Input resistance.* The measured 3.91 kΩ is 18% above the predicted 3.31 kΩ. Since $R_i approx R_"TH" || r_pi$ and $r_pi = beta V_T\/I_C$, the measured value implies $r_pi approx 4.56k Omega$ and therefore $beta approx 195$ at 1.11 mA. That is consistent with the higher-than-designed collector current noted above. Cross-checking with $v_s - v_i = 2.0m V$ instead of the measured $V_(R_S) = 2.3m V$ gives $R_i = 4.5k Omega$, so the result is sensitive to millivolt-level readings.

*Output resistance.* The measured 4.66 kΩ is 20% below $R_C || r_o = 5.83k Omega$. Theory predicts the output should rise by a factor $(R_o + R_L)\/R_L = 3.65$ when $R_L$ is removed; the measured ratio was $960\/308 = 3.12$. Because $R_o = R_L (v_o\/v_L - 1)$, a small error in that ratio becomes a larger error in $R_o$. Likely contributors are the tolerance of $R_C$ and $R_L$, and gain compression on the larger unloaded output (about $2.7V_"pp"$). With $v_"be"$ already at 5 mV rms, the exponential $i_C$–$v_"BE"$ characteristic of the bypassed stage starts to add distortion.

=== Emitter Follower
The emitter follower matched the predictions closely. $A_"vi" = 0.970$ and $A_"vs" = 0.914$ are both within 1% of the calculated and simulated values, and the output was in phase with the input. The output resistance of 34.4 Ω is within 3% of the predicted 35.4 Ω. Loading the follower with $R_L$ changed the output by only 0.1 mV, which shows how well the follower works as a buffer.

The input resistance is the one outlier: 9.14 kΩ measured against 23.4 kΩ predicted. In this circuit $v_s$ and $v_i$ differ by only 0.4 mV, so $i_s$ is tiny and hard to measure. The directly measured $V_(R_S) = 1.3m V$ is inconsistent with $v_s - v_i = 7.0 - 6.6 = 0.4m V$. Using the difference instead gives $i_s = 0.22 mu A$ and $R_i = 6.6m V\/0.22 mu A = 29.7k Omega$, which is on the other side of the predicted value. Both readings are near the meter's resolution on the millivolt range (±0.05 mV on each reading is a ±25% uncertainty on 0.4 mV). The floating measurement across $R_S$ also picks up noise and common-mode error. The predicted 23.4 kΩ lies between the two estimates, so the measurement does not contradict theory, but it cannot pin down $R_i$ accurately. A larger series resistor (or a larger input amplitude) would make $v_s - v_i$ large enough to measure reliably.

=== Comparison of Configurations
The CE amplifier with $C_E$ gives high voltage gain (about −62 from $v_i$) but a low input resistance (about 3–4 kΩ) and a high output resistance (about $R_C$). Removing $C_E$ (pre-lab and simulation) cuts the gain to below unity with this load, but raises $R_i$ to about 25 kΩ and makes the gain almost independent of $beta$. The emitter follower has no voltage gain, but it combines a high input resistance with an output resistance of about 35 Ω, more than 100 times lower than the CE stage.

== Conclusion
The pre-lab hand analysis, SPICE simulation and lab measurements agreed well for the two key behaviors studied. The bypassed common-emitter stage produced an inverted gain of $A_"vi" = -61.6$ (−63.7 predicted). The emitter follower produced near-unity, in-phase gain of $A_"vi" = 0.970$ (0.975 predicted) with an output resistance of 34.4 Ω (35.4 Ω predicted). The larger discrepancies, in $V_"CEQ"$, the CE output resistance and the follower input resistance, are explained by the transistor's real $beta$ being higher than 150, resistor tolerances, and the difficulty of measuring sub-millivolt differences and microamp-level signal currents.

From this experiment we learned how strongly the emitter bypass capacitor sets the trade-off between gain and input resistance in a CE stage. We saw why an emitter follower, despite having no voltage gain, is useful as a buffer between a high-resistance source and a low-resistance load. We also learned that small-signal measurements need care: oscilloscope peak-to-peak readings on 20 mV signals are dominated by noise, so RMS multimeter readings were needed. Quantities computed from the difference of two nearly equal voltages (such as $R_i$ of the follower) need a test setup that makes that difference large enough to measure. These results feed directly into Experiment 6, where a multistage amplifier will combine a CE gain stage with an emitter-follower output stage.

#pagebreak()
== Appendix: Pre-Lab Calculation Script
```python
VCC, RC, RE, RL, RS = 12, 6.2e3, 1.8e3, 2.2e3, 1.8e3
R1, R2 = 120e3, 36e3
beta, VBE, VT, VA, VCEsat = 150, 0.7, 0.026, 100, 0.2
par = lambda *r: 1 / sum(1 / x for x in r)

# Bias (same for all three circuits)
RTH = par(R1, R2); VTH = VCC * R2 / (R1 + R2)
IB = (VTH - VBE) / (RTH + (beta + 1) * RE)
IC = beta * IB; IE = (beta + 1) * IB
gm = IC / VT; rpi = beta / gm; ro = VA / IC

# CE with bypass capacitor
VCE = VCC - IC * RC - IE * RE
Rac = par(RC, RL)
vo_max = min(IC * Rac, VCE - VCEsat)
Ri = par(RTH, rpi)
Avi = -gm * par(RC, RL, ro); Avs = Avi * Ri / (Ri + RS)
Ro = par(RC, ro)

# CE without bypass capacitor
vo_max_nb = min(IC, (VCE - VCEsat) / (Rac + RE)) * Rac
Rib = rpi + (beta + 1) * RE
Ri_nb = par(RTH, Rib)
Avi_nb = -beta * Rac / Rib; Avs_nb = Avi_nb * Ri_nb / (Ri_nb + RS)

# Emitter follower
VCE_ef = VCC - IE * RE
vo_max_ef = min(IE * par(RE, RL), VCE_ef - VCEsat)
REp = par(RE, RL, ro)
Rib_ef = rpi + (beta + 1) * REp
Ri_ef = par(RTH, Rib_ef)
Avi_ef = (beta + 1) * REp / Rib_ef; Avs_ef = Avi_ef * Ri_ef / (Ri_ef + RS)
Ro_ef = par((rpi + par(RTH, RS)) / (beta + 1), RE, ro)
```
